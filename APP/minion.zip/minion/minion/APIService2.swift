//
//  APIService2.swift
//  minion
//
//  Created by Jorge Bustamante on 09/06/24.
//

import Foundation




class APIService2 {
    static let shared = APIService2()

    


    

}

