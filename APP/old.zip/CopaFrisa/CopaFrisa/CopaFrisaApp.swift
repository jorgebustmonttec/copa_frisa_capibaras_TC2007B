//
//  CopaFrisaApp.swift
//  CopaFrisa
//
//  Created by Jorge Bustamante on 30/04/24.
//

import SwiftUI

@main
struct CopaFrisaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
