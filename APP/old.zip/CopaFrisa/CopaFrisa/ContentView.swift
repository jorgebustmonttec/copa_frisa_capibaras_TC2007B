//
//  ContentView.swift
//  CopaFrisa
//
//  Created by Jorge Bustamante on 30/04/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, tilin")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
